﻿using System.Runtime.CompilerServices;

//Make internals visible for testing
[assembly: InternalsVisibleTo("DarkRift.Testing")]
[assembly: InternalsVisibleTo("DarkRift.Client")]
[assembly: InternalsVisibleTo("DarkRift.Server")]