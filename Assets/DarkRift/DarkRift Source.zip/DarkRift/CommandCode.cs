﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     Command codes for control sequences to clients/servers.
    /// </summary>
    internal enum CommandCode : ushort
    {
        /// <summary>
        ///     A identification packet presenting a new ID to a client.
        /// </summary>
        Configure = 0,              //                  [ID, ID]

        /// <summary>
        ///     An identification packet presenting a preknown ID to server.
        /// </summary>
        Identify = 1,              //                  [ID, ID]
    }
}
