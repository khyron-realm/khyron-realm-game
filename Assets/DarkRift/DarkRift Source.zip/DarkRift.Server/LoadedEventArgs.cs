﻿namespace DarkRift.Server
{
    /// <summary>
    ///     Event arguments for when plugins have loaded.
    /// </summary>
#if PRO
    public 
#else
    internal
#endif
        class LoadedEventArgs
    {
    }
}