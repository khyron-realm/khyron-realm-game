﻿namespace DarkRift.Server
{
#if PRO
    /// <summary>
    ///     Manager for the server registry connectors.
    /// </summary>
    public interface IServerRegistryConnectorManager
    {
        /// <summary>
        ///     The server registry connector.
        /// </summary>
        ServerRegistryConnector ServerRegistryConnector { get; set; }
    }
#endif
}
