﻿namespace DarkRift.Server.Metrics
{
#if PRO
    /// <summary>
    /// A metric representing the current value of a property, able to increase or decrease.
    /// </summary>
    /// <remarks>
    ///     Pro only.
    /// </remarks>
    public interface IGaugeMetric
    {
        /// <summary>
        /// Set the value of this gauge to that specified.
        /// </summary>
        /// <param name="value">The value of the gauge to set.</param>
        void Report(double value);
    }
#endif
}
