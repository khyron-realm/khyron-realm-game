﻿namespace DarkRift.Server.Metrics
{
#if PRO
    /// <summary>
    /// A metric capable only of increasing in value.
    /// </summary>
    /// <remarks>
    ///     Pro only.
    /// </remarks>
    public interface ICounterMetric
    {
        /// <summary>
        /// Increase the value of the counter by 1.
        /// </summary>
        void Increment();

        /// <summary>
        /// Increase the value of the counter by a specified amount.
        /// </summary>
        /// <param name="value">The amount to increase the counter by.</param>
        void Increment(double value);
    }
#endif
}
