# Hello!
This is the DarkRift reference source. This archive contains all the closed-source source code of the DarkRift Networking Pro asset, any remaining code is likely to be open source and available on github [here](https://github.com/DarkRiftNetworking).

## License and Purpose
This code is bound by the [Asset Store EULA](https://unity3d.com/legal/as_terms) and is copyright Jamie Read (the author) - All rights reserved.

The purpose of supplying this code to you is for you to learn and understand how DarkRift works internally and to serve as a reference for debugging. While you are free to modify the code it is recommended you leave it as supplied and support for modified code may be limited.