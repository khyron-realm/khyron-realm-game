﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DarkRift.Server;
using System.Threading;
using System.IO;
using System.Collections.Specialized;
using System.Collections;

namespace DarkRift.Server.Console
{
    internal class Program
    {
        /// <summary>
        ///     The server instance.
        /// </summary>
        private static DarkRiftServer server;

        /// <summary>
        ///     Main entry point of the server which starts a single server.
        /// </summary>
        /// <param name="args"></param>
        private static void Main(string[] args)
        {
            string[] rawArguments = CommandEngine.ParseArguments(string.Join(" ", args));
            string[] arguments = CommandEngine.GetArguments(rawArguments);
            NameValueCollection variables = CommandEngine.GetFlags(rawArguments);

            foreach (DictionaryEntry environmentVariable in Environment.GetEnvironmentVariables())
                variables.Add((string)environmentVariable.Key, (string)environmentVariable.Value);

            string serverConfigFile;
            string clusterConfigFile;
            if (arguments.Length < 1)
            {
                serverConfigFile = "Server.config";
                clusterConfigFile = "Cluster.config";
            }
            else if (arguments.Length == 1)
            {
                serverConfigFile = arguments[0];
                clusterConfigFile = "Cluster.config";
            }
            else if (arguments.Length == 2)
            {
                serverConfigFile = arguments[0];
                clusterConfigFile = arguments[1];
            }
            else
            {
                System.Console.Error.WriteLine("Unexpected number of comand line arguments passed. Expected 0-2 but found " + arguments.Length + ".");
                System.Console.WriteLine("Press any key to exit...");
                System.Console.ReadKey();
                return;
            }

            ServerSpawnData serverSpawnData;

            try
            {
                serverSpawnData = ServerSpawnData.CreateFromXml(serverConfigFile, variables);
            }
            catch (IOException e)
            {
                System.Console.Error.WriteLine("Could not load the server config file needed to start (" + e.Message + "). Are you sure it's present and accessible?");
                System.Console.WriteLine("Press any key to exit...");
                System.Console.ReadKey();
                return;
            }
            catch (XmlConfigurationException e)
            {
                System.Console.Error.WriteLine($"Failed to load '{serverConfigFile}': {e.Message}");
                System.Console.Error.WriteLine();
                System.Console.Error.WriteLine(e.DocumentationLink != null ? $"See {e.DocumentationLink} for more information." : "No additional documentation available.");
                System.Console.Error.WriteLine();
                System.Console.Error.WriteLine(e.LineInfo != null && e.LineInfo.HasLineInfo() ? $"Line {e.LineInfo.LineNumber} Col: {e.LineInfo.LinePosition}" : "(Unknown location)");
                System.Console.Error.WriteLine();
                System.Console.WriteLine("Press any key to exit...");
                System.Console.ReadKey();
                return;
            }

            // Set this thread as the one executing dispatcher tasks
            serverSpawnData.DispatcherExecutorThreadID = Thread.CurrentThread.ManagedThreadId;

#if PRO
            if (File.Exists(clusterConfigFile))
            {
                ClusterSpawnData clusterSpawnData;
                try
                {
                    clusterSpawnData = ClusterSpawnData.CreateFromXml(clusterConfigFile, variables);
                }
                catch (IOException e)
                {
                    System.Console.Error.WriteLine("Could not load the cluster config file needed to start (" + e.Message + "). Are you sure it's present and accessible?");
                    System.Console.WriteLine("Press any key to exit...");
                    System.Console.ReadKey();
                    return;
                }
                catch (XmlConfigurationException e)
                {
                    System.Console.Error.WriteLine($"Failed to load '{clusterConfigFile}': {e.Message}");
                    System.Console.Error.WriteLine();
                    System.Console.Error.WriteLine(e.DocumentationLink != null ? $"See {e.DocumentationLink} for more information." : "No additional documentation available.");
                    System.Console.Error.WriteLine();
                    System.Console.Error.WriteLine(e.LineInfo != null && e.LineInfo.HasLineInfo() ? $"Line {e.LineInfo.LineNumber} Col: {e.LineInfo.LinePosition}" : "(Unknown location)");
                    System.Console.Error.WriteLine();
                    System.Console.WriteLine("Press any key to exit...");
                    System.Console.ReadKey();
                    return;
                }

                server = new DarkRiftServer(serverSpawnData, clusterSpawnData);
            }
            else
            {
                server = new DarkRiftServer(serverSpawnData);
            }
#else
            server = new DarkRiftServer(serverSpawnData);
#endif


            server.StartServer();

            new Thread(new ThreadStart(ConsoleLoop)).Start();

            while (!server.Disposed)
            {
                server.DispatcherWaitHandle.WaitOne();
                server.ExecuteDispatcherTasks();
            }
        }

        /// <summary>
        ///     Invoked from another thread to repeatedly execute commands from the console.
        /// </summary>
        private static void ConsoleLoop()
        {
            while (!server.Disposed)
            {
                string input = System.Console.ReadLine();

                if (input == null)
                {
                    System.Console.WriteLine("Stopping input loop as we seem to be running without an input stream.");
                    return;
                }

                server.ExecuteCommand(input);
            }
        }
    }
}
