﻿using System;
using System.IO;
using System.Net;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using TechTalk.SpecFlow;
using static DarkRift.Server.DarkRiftInfo;

namespace DarkRift.SystemTesting
{
    /// <summary>
    ///     Steps for testing the server's health check
    /// </summary>
    [Binding]
    internal class PrometheusSteps
    {
        /// <summary>
        ///     The world to store state in.
        /// </summary>
        private readonly World world;

        /// <summary>
        ///    The downloaded Prometheus metric data.
        /// </summary>
        private string prometheusString;

        public PrometheusSteps(World world)
        {
            this.world = world;
        }

        [When("I query the Prometheus endpoint")]
        public void WhenIQueryTheHealthCheckPort()
        {
            using WebClient webClient = new WebClient();
            prometheusString = webClient.DownloadString("http://localhost:9796/metrics");
        }

        [Then("the server returns the metrics in (.*)")]
        public void ThenTheServerReturnsTheExpectedMetrics(string expectedMetricsFile)
        {
            // Assert line by line for better debugging
            string[] expectedLines = File.ReadAllLines(expectedMetricsFile);
            string[] actualLines = prometheusString.Split('\n');

            Assert.AreEqual(expectedLines.Length, actualLines.Length);
            for (int i = 0; i < expectedLines.Length; i++)
            {
                if (expectedLines[i].StartsWith("#") || string.IsNullOrWhiteSpace(expectedLines[i]))
                {
                    Assert.AreEqual(expectedLines[i], actualLines[i], $"Expected comment on line {i + 1} to match.");
                }
                else
                {
                    Assert.AreEqual(
                        expectedLines[i].Substring(0, expectedLines[i].LastIndexOf(' ')),
                        actualLines[i].Substring(0, actualLines[i].LastIndexOf(' ')),
                        $"Expected metric on line {i + 1} to match."
                    );
                }
            }
        }
    }
}
