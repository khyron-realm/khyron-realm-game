// This file serves solely to make docfx see pro feature during a build
#define PRO
