# ConnectsTo Element
The `<connectsTo>` element defines a connection from one server group to another.

## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| name |  | The name of the server group that will be connected to. |

## Child Elements
There are no child elements for this element.

