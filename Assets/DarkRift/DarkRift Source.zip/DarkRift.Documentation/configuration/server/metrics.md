# Metrics Element
`<metrics>` element is used to specify a metrics settings for the server.

## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| enablePerMessageMetrics | `true` or `false` | Whether internal metrics that will be emitted every message should be enabled. |

## Child Elements
- metricsWriter
