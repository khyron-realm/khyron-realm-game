# Data Element
The `<data>` element is used to specify where the server stores persistent data.

## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| directory (required) | Any filesystem location | The directory to store persistent data. |

## Child Elements
There are no child elements for this element.
