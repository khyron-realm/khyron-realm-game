# Database Element
The `<database>` element specifies a database connection string.
      
## Attributes
| Attribute | Values | Description |
|-----------|--------|-------------|
| name |  | The name of the connection string. |
| connectionString |  | The actual database string. |
            
## Child Elements
There are no child elements for this element.
