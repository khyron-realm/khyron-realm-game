# Debug Writer
The `DebugWriter` in the `DarkRift.Server.Plugins.LogWriters` namespace provides a log writer that writes to `System.Diagnostics.Debug`.
