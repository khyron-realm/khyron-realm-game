# Demo Command
The `DemoCommand` sets the DarkRift server to demonstration mode where all packets received are broadcast back to all clients.

## Commands
The following commands are exposed:

| Command   | Usage | Description |
|-----------|-------|-------------|
| `demo` | `demo` | Redirects all traffic to all other clients for demonstration purposes. |
